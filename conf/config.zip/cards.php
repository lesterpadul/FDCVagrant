<?php
# --- CREDIT CARD DATA ---
# TEST CLIENTIP
$config['ZEUS_clientip'] = 2019000965;
// $config['AXES_clientip'] = 1019000635;

# --- NEXMO SMS DATA ---
#$config['nexmo_api_key'] = '11111111';
#$config['nexmo_api_secret'] = '11111111';


// worldpay
$config['worldpay.merchant_code_debit_auth_usd'] = 'NATIVECAMPUSD';
$config['worldpay.merchant_code_debit_payment_usd'] = 'NATIVECAMPCAUSD';
$config['worldpay.merchant_code_credit_auth_usd'] = 'NATIVECAMPAPMUSD';
$config['worldpay.merchant_code_credit_payment_usd'] = 'NATIVECAMPAPMCAUSD';
$config['worldpay.default_password'] = 'live2018';
$config['worldpay.default_installation_id'] = 1318418;
