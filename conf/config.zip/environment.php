<?php
$config["ENVIRONMENT"] = "LOCAL";
?>
