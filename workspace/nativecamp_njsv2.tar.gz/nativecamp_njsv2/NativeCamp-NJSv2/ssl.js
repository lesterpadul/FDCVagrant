/* require fs */
var fs = require("fs");

/* ssl information */
module.exports = {
	/* set default port */
	port: 3000,
	
	/* database information */
	dbName: "english",
	dbHost: "local.nativecamp.net",
	dbUser: "root",
	dbPass: "123",
	dbTime: "+09:00", // set to japanese time
	
	/* ssl files */
	options: {
		key: fs.readFileSync('/vagrant/ssl/stg-node.nativecamp.net.nopass.key'),
		cert: fs.readFileSync('/vagrant/ssl/stg-node.nativecamp.net.crt'),
		ca: fs.readFileSync('/vagrant/ssl/stg-node.nativecamp.net.ca.crt')
	},
	
	/* allowed sites */
	origins: ""
};
