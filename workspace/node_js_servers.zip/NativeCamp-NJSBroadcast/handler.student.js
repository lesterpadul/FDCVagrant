/* set dependencies */
var util = require('./util.js');
var constant = require('./constant.js');

/* export student functions */
module.exports = {
	registerRoom: function(obj, resolve, reject){
		if (typeof obj.data === undefined){
			return reject('reason_invalid_object_data');
		}

		if (typeof obj.roomsStudent === undefined){
			return reject('reason_invalid_object_room_students');
		}

		if (typeof obj.roomsTeacher === undefined){
			return reject('reason_invalid_object_room_teachers');
		}

		// active students rooms
		var studentsRooms = obj.roomsStudent;
		// active teachers room
		var teachersRooms = obj.roomsTeacher;
		// users info
		var data = obj.data;

		// check student room using student id as its index
		util.log('[ROOM - STUDENT] CHECKING FROM ROOM STUDENT -> ' +JSON.stringify(data) + ' index-> user_' + data.userId, 'yellow');

		// inserting / updating the user to student room
		studentsRooms['user_' + data.userId] = {
			userId: data.userId,
			teacherId: data.teacherId,
			created: util.getCurrentTime()
		};

		// get teacher room index
		util.log('[ROOM - TEACHER] CHECKING FROM ROOM TEACHER -> ' +JSON.stringify(data) + ' index-> teacher_' + data.teacherId, 'yellow');

		// if teacher not exists insert new room for teacher
		if (typeof teachersRooms['teacher_' + data.teacherId] === 'undefined') {
			util.log('[ROOM - TEACHER] INSERT TEACHER TO ROOM TEACHER -> ' +JSON.stringify(data) + ' index-> teacher_' + data.teacherId, 'green');
			teachersRooms['teacher_' + data.teacherId] = {
				teacherId: data.teacherId,
				workstationId: "",
				status: 4,
				created: util.getCurrentTime()
			};
		}

		return resolve();
	},

	leaveRoom: function(obj){
		// check if the teachers array or data from teacher exists
		if(typeof obj.rooms === undefined || typeof obj.data === undefined) {
			return reject("reason_invalid_student_params");
		}

		// get data
		var rooms = obj.rooms;
		var data = obj.data;
		// checks if user exists on students room
		if(typeof rooms['user_' + data.userId] !== 'undefined') {
			util.log('[DISCONNECTION - STUDENT] REMOVING STUDENT FROM ROOM STUDENT: '+JSON.stringify(rooms['user_' + data.userId]), 'red');
			delete rooms['user_' + data.userId];
		}
	}
};