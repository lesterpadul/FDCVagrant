var connect = require("./connect.js");
var handler = require("./handler.js");
var util = require("./util.js");
var moment = require("moment");


/*
 * teachers Room object format
 * {
 *	teacher_id : 1,
 *	workstation_id : 1,
 *	status : 1		// teacher's current status
 * lesson_with: 1 // user id
 * }
 */
var roomsTeacher = [];
/*
 * teachers Room object format
 * {
 *	teacherId : {
 *		studentId : '',
 *		teacherId: ''}
 * }
 */
var roomsStudent = [];
var roomsAdmin = [{
	adminId: ''
}];

var connectedTeachers = {
	connectedTeachers: "connectedTeachers",
	connectedTeachersArr: {},
	standby: {},
	notStandby: {},
	break: {},
	mealBreak: {},
	other: {},
	onLesson: {},
	reservation: {}
};

function adminLog(msg, obj) {
	console.log('admin-monitor: ' + msg);
	if (obj) {
		console.log(obj);
	}
}

var adminMonitorRooms = {};
var adminTeacherMonitorImages = {};

var objChivoxUsers = {};
var maxChivoxUsers = 7;

/* output debugger for signaling server */
util.log("[SERVER] STARTING BROADCAST SERVER", 'green');
util.log("[HANDLER] HANDLERS LOADED", 'green');
/* socket connections */
connect.io.on('connection', function(socket){

	/**
	* register to what type of room
	* @param data -> configuration depending on which memberType
	*/
	socket.on('common.generalCommand', function(data, callback){
		// declare and assign variable object
		var obj = {error: false, content:""};
		util.try(function(resolve, reject){

			/* if data.content is undefined */
			if(typeof data.content === "undefined"){
				obj.content = "reason_unknown_content";
				obj.error = true;
				return reject(obj);
			}

			/* if data.content.memberType is undefined */
			if(typeof data.content.memberType === "undefined"){
				obj.content = "reason_unknown_member_type";
				obj.error = true;
				return reject(obj);
			}

			switch (data.command) {
				case "registerRoom":

					/* identify type of member */
					switch(data.content.memberType){
						case "student":
							handler.student.registerRoom({
								data: data.content,
								roomsStudent: roomsStudent,
								roomsTeacher: roomsTeacher,
								roomsAdmin: roomsAdmin
							}, resolve, reject);
							break;

						case "teacher":
							handler.teacher.registerRoom({
								data: data.content,
								roomsTeacher: roomsTeacher,
								roomsAdmin: roomsAdmin,
								connectedTeachers: connectedTeachers
							}, resolve, reject);
							break;

						case "admin":
							break;

						default:
					}

					break;
				/* user has started the lesson and inform other user about the new teacher status */
				case "lessonStart":
					handler.common.lessonStart({
						data: data.content,
						roomsTeacher: roomsTeacher
					}, resolve, reject);
					break;
				/* during refreshing the teacher side page, send the updated teacher statistics to other connected teachers */
				case "teacherStatusState":
					return resolve();
					break;


				/* updating connected teacher via ajax from client side */
				case "updateRoomState":
					handler.teacher.updateRoomState({
						data: data.content,
						roomsTeacher: roomsTeacher,
						connectedTeachers: connectedTeachers
					}, resolve, reject);
					break;
				case "adminConnected":
					adminLog('admin connected', data);

					adminMonitorRooms['admin-monitor-' + data.content.adminId] = {
						teachers: data.content.teachers
					};

					var teachersInMonitor = Object.keys(data.content.teachers);
					var dataTeacherImages = {};
					socket.userData = data.content;
					resolve();
					break;

				case "storeSnapShot":

					var teacherId = typeof data.content.teacherId !== undefined ? data.content.teacherId : '';
					var teacherImage = typeof data.content.image !== undefined ? data.content.image : '';

					if (teacherId && teacherImage) {
						adminTeacherMonitorImages[teacherId] = {
							teacherId: teacherId,
							teacherImage: teacherImage,
							created: util.getCurrentTime(),
						};
					}
					resolve();

					break;
				/* force teacher to logout from admin side */
				case "forceTeacherLogout":
				case "forceTerminateLesson":
				default:
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: data.command,
						content: { data : data.content, connectedTeachers : connectedTeachers }
					});
					resolve();
			}

		})
		.then(function(content){
			// set socket information
			socket.userData = data.content;

			var memberType = socket.userData.memberType;

			var command = data.command;

			switch (command) {
				case "registerRoom":
					if (memberType == "student"){
						util.log('STUDENT TO JOIN ON TEACHERS ROOM');
						// if teacher exist in room then teacher is online
						if (typeof roomsTeacher['teacher_' + socket.userData.teacherId] !== 'undefined') {
							util.log('USER JOINED TO TEACHER ROOM INDEX: teacher_' + socket.userData.teacherId + ' ' + JSON.stringify(roomsTeacher['teacher_' + socket.userData.teacherId]));
							util.log('USER HAS JOINED TO TEACHER: '+roomsTeacher['teacher_' + socket.userData.teacherId].teacherId);

							// join the user to this teacher
							socket.join(roomsTeacher['teacher_' + socket.userData.teacherId].teacherId);
							// broadcast the teacher data including the broadcaster
							connect.io.in(socket.userData.teacherId).emit('common.generalCommand',{
								command: "updateTeacherStatus",
								content: roomsTeacher['teacher_' + socket.userData.teacherId]
							});
						} else {
							// teacher is offline
							util.log('TEACHER NOT EXIST, OFFLINE');
						}
					} else if (memberType == "teacher"){
						/* broadcast to all students who were connected to this teacher's detail page about the new status of this teacher */
						connect.io.in(socket.userData.teacherId).emit('common.generalCommand', {
							command: "updateTeacherStatus",
							content: data.content
						});

						/* get rooms from admin monitor rooms */
						var adminRooms = Object.keys(adminMonitorRooms);

						/* teacher id */
						var teacherId = data.content.teacherId.toString();

						console.log(adminMonitorRooms);

						/* loop all rooms */
						for (var room in adminRooms) {
							
							/* room index */
							var roomIndex = adminRooms[room];

							/* checks if teacher is connected from 1 of the admins */
							if (
								adminMonitorRooms &&
								typeof adminMonitorRooms[roomIndex] !== undefined &&
								typeof adminMonitorRooms[roomIndex].teachers !== undefined &&
								typeof adminMonitorRooms[roomIndex].teachers[teacherId] !== undefined
							) {

								data.content.teacherTrigger = true;

								/* start taking snapshot */
								socket.emit('common.generalCommand', {
									command: 'teacherStartSnapshot',
									content: data.content
								});
								break;
							}
						}

					} else {
						util.log("admin");
					}
					break;
				/* if student triggered the advance to lesson inform the other users who were connected to this teacher's detail page */
				case "lessonStart":
					if (memberType == "student"){
						connect.io.in(socket.userData.teacherId).emit('common.generalCommand',{
							command: "lessonStart",
							content: data.content
						});
					}
					break;
				/* teachers statistics */
				case "teacherStatusState":
					if (memberType == "teacher"){
						socket.join(connectedTeachers.connectedTeachers);
						// broadcast data includding the sender
						/* broadcast the teacher statistics to all connected teachers */
						connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
							command: data.command,
							content: { data : data.content, connectedTeachers : connectedTeachers }
						});
					}
					break;

				/* teachers statistics and users connected to this user */
				case "updateRoomState":
					/* broadcast to teacher statistics to all connected teachers */
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: "updateTeacherRoomState",
						content: { data : data.content, connectedTeachers : connectedTeachers }
					});
					/* broadcast to all users that are connected to this teacher */
					socket.broadcast.to(data.content.teacherId).emit('common.generalCommand', {
						command: "updateTeacherStatus",
						content: data.content
					});

					break;

				default:

			}

		})
		.catch(function(err){
			util.log(JSON.stringify(data));
			util.log(JSON.stringify(err));
			util.logError("[ROOM] "+ err);
			obj.error = true;
			obj.content = err;
		})
		.then(function(){
			return callback(obj);
		})
	});
	
	/**
	 * [description]
	 * @param  {[type]} ){	} [description]
	 * @return {[type]}        [description]
	 */
	socket.on('chivox.register', function(data){
		// - prepare parameters
		var userId = data.user_id || "";
		var deviceType = data.device_type || "";
		var maxCount = data.max_chivox_count || maxChivoxUsers;

		// - response
		var sockResponse = {
			"error": true,
			"count": 0,
			"message": ""
		};

		// - set user info
		var objChivUser = {
			"user_id": userId,
			"device_type": deviceType,
		};

		// - log information
		util.log("[CHIVOX] attempting chivox information - " + JSON.stringify(data));

		// - if user_id is empty
		if (userId.length == 0) {
			util.log("[CHIVOX] invalid user_id supplied - " + JSON.stringify(data));
			sockResponse.message = "invalid_user_id";
			return socket.emit("chivox.response", sockResponse);
		}

		// - if user_id is empty
		if (deviceType.length == 0) {
			sockResponse.message = "invalid_device_type";
			util.log("[CHIVOX] invalid device_type supplied - " + JSON.stringify(data));
			return socket.emit("chivox.response", sockResponse);
		}

		// - check if device_type is valid
		if (deviceType < 0 || deviceType >= 4) {
			sockResponse.message = "unsupported_device_type";
			util.log("[CHIVOX] invalid device_type supplied - " + JSON.stringify(data));
			return socket.emit("chivox.response", sockResponse);
		}
		
		// - check if current user count is still within allowed occupancy
		if (typeof objChivoxUsers[userId] === "undefined") {
			var currentCount = util.size(objChivoxUsers);
			if (maxCount <= currentCount) {
				sockResponse.message = "max_occupancy_reached";
				util.log("[CHIVOX] max count reached - " + JSON.stringify(objChivoxUsers));
				util.log("[CHIVOX] max count reached, max - " + (maxCount));
				util.log("[CHIVOX] max count reached, current - " + (currentCount));
				return socket.emit("chivox.response", sockResponse);
			}

		// - continue normally
		} else {
			// - log information
			util.log("[CHIVOX] user already exists, continiuing - " + JSON.stringify(objChivoxUsers));

		}

		// - set chivox user
		objChivoxUsers[userId] = objChivUser;

		// - log information
		util.log("[CHIVOX] added chivox data - " + JSON.stringify(objChivoxUsers));

		// - set socket variable
		socket.chivox_user = objChivUser;

		// - set information
		sockResponse.error = false;
		sockResponse.count = util.size(objChivoxUsers);
		sockResponse.message = "connection_successful";
		
		// - return successful response
		return socket.emit("chivox.response", sockResponse);
	});

	/* catch disconnection module */
	socket.on('disconnect', function(action){
		util.log('[DISCONNECTION]');

		console.log(userData);

		// get userdata from socket
		var userData = socket.userData;

		// - if has chivox information
		if (
			typeof socket.chivox_user !== "undefined" &&
			typeof objChivoxUsers[socket.chivox_user.user_id] !== "undefined"
		) {
			delete objChivoxUsers[socket.chivox_user.user_id];
			util.log("[CHIVOX] triggered disconnection, removing chivox data - " + JSON.stringify(objChivoxUsers));

		}
		
		// - disconnect
		util.try(function(resolve,reject){

			// get the member type
			var memberType = (typeof userData.memberType === "undefined") ? 'unknown' : userData.memberType;
			var command = "";

			if (memberType == "student"){
				command = "studentDisconnect";
				userData.command = command;
				handler.student.leaveRoom({
					data: userData,
					rooms: roomsStudent
				});

			} else if (memberType == "teacher"){
				// command = "updateTeacherStatus";
				command = "updateTeacherRoomState";
				userData.command = command;
				userData.status = 4;

				socket.userData = userData;

				handler.teacher.leaveRoom({
					data: userData,
					roomsTeacher: roomsTeacher,
					roomsAdmin: roomsAdmin,
					connectedTeachers: connectedTeachers
				});

			} else {
				command = "adminDisconnect";
				userData.command = command;
				socket.userData = userData;

				delete adminMonitorRooms['admin-monitor-' + userData.adminId];
			}

			// resolve
			resolve();
		})
		.then(function(){
			var userData = socket.userData;

			var command = userData.command;

			switch (command) {
				case "updateTeacherRoomState":
					// broadcast data includding the sender
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: "updateTeacherRoomState",
						content: { data : userData, connectedTeachers : connectedTeachers }
					});
					connect.io.in(userData.teacherId).emit('common.generalCommand', {command: "updateTeacherStatus", content:userData});
					break;
				default:
			}


			socket.leave();
		})
		.catch(function(err){
			util.log(JSON.stringify(userData), 'white', 'magenta');
			util.logError("[DISCONNECTION] "+ err);
		})
		.then(function(){
			socket.leave();
		});
	});
});