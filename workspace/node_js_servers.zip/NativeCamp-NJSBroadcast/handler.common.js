/* set dependencies */
var util = require('./util.js');
var constant = require('./constant.js');
var element = null;

/* export */
module.exports = {
	sendChat: function(obj,resolve){
		resolve();
	},
	addActionLog: function(conditions, values){
		model.logAction(conditions, values);
	},
	lessonStart: function(obj, resolve, reject){
		if (typeof obj === undefined){
			return reject('reason_undefined_obj')
		}

		if (typeof obj.content === undefined){
			return reject('reason_undefined_content');
		}

		if (typeof obj.roomsTeacher === undefined){
			return reject('reason_undefined_rooms_teacher');
		}

		var roomsTeacher = obj.roomsTeacher;
		var userData = obj.data;

		// teacher already exists in roomsTeacher
		if (typeof roomsTeacher['teacher_' + userData.teacherId] !== 'undefined') {
			roomsTeacher['teacher_' + userData.teacherId].status = 3;
			roomsTeacher['teacher_' + userData.teacherId].created = util.getCurrentTime();
		}

		util.log('LESSON START, TEACHER ROOM INFO: '+JSON.stringify(roomsTeacher));

		return resolve();
	}
};