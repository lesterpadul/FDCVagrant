var connect = require("./connect.js");
var handler = require("./handler.js");
var util = require("./util.js");
var moment = require("moment");


/*
 * teachers Room object format
 * {
 *	teacher_id : 1,
 *	workstation_id : 1,
 *	status : 1		// teacher's current status
 * lesson_with: 1 // user id
 * }
 */
var roomsTeacher = [];
/*
 * teachers Room object format
 * {
 *	teacherId : {
 *		studentId : '',
 *		teacherId: ''}
 * }
 */
var roomsStudent = [];
var roomsAdmin = [{
	adminId: ''
}];
// room for teacher connected to admin
var roomsTeacherConnectedToAdmin = {};

// admin calling queue
var adminCallQueue = {};

var connectedTeachers = {
	connectedTeachers: "connectedTeachers",
	connectedTeachersArr: {},
	standby: {},
	notStandby: {},
	break: {},
	mealBreak: {},
	other: {},
	onLesson: {},
	reservation: {}
};

/* output debugger for signaling server */
util.log("[SERVER] STARTING BROADCAST SERVER", 'green');
util.log("[HANDLER] HANDLERS LOADED", 'green');
/* socket connections */
connect.io.on('connection', function(socket){

	/**
	* register to what type of room
	* @param data -> configuration depending on which memberType
	*/
	socket.on('common.generalCommand', function(data, callback){
		// declare and assign variable object
		var obj = {error: false, content:""};
		util.try(function(resolve, reject){

			/* if data.content is undefined */
			if(typeof data.content === "undefined"){
				obj.content = "reason_unknown_content";
				obj.error = true;
				return reject(obj);
			}
			console.log(data.command);
			/* if data.content.memberType is undefined */
			if(typeof data.content.memberType === "undefined"){
				obj.content = "reason_unknown_member_type";
				obj.error = true;
				return reject(obj);
			}

			switch (data.command) {
				case "registerRoom":

					/* identify type of member */
					switch(data.content.memberType){
						case "student":
							handler.student.registerRoom({
								data: data.content,
								roomsStudent: roomsStudent,
								roomsTeacher: roomsTeacher,
								roomsAdmin: roomsAdmin
							}, resolve, reject);
							break;

						case "teacher":
							handler.teacher.registerRoom({
								data: data.content,
								roomsTeacher: roomsTeacher,
								roomsAdmin: roomsAdmin,
								connectedTeachers: connectedTeachers
							}, resolve, reject);
							break;

						case "admin":
							break;

						default:
					}

					break;
				/* user has started the lesson and inform other user about the new teacher status */
				case "lessonStart":
					handler.common.lessonStart({
						data: data.content,
						roomsTeacher: roomsTeacher
					}, resolve, reject);
					break;
				/* during refreshing the teacher side page, send the updated teacher statistics to other connected teachers */
				case "teacherStatusState":
					return resolve();
					break;


				/* updating connected teacher via ajax from client side */
				case "updateRoomState":
					handler.teacher.updateRoomState({
						data: data.content,
						roomsTeacher: roomsTeacher,
						connectedTeachers: connectedTeachers
					}, resolve, reject);
					break;
				case "adminTeacherMonitorConnect":
					/* socket user data */
					socket.userData = data.content;

					// register teachers to admin room
					handler.admin.registerTeacherToAdminRoom({
						data: data.content,
						roomsTeacherConnectedToAdmin: roomsTeacherConnectedToAdmin,
						adminCallQueue: adminCallQueue
					}, resolve, reject);
					
					// broadcast data to self
					socket.emit('common.generalCommand', {
						command: data.command,
						content: { data : data.content, connectedTeachers : connectedTeachers }
					});
					break;
				case "adminTeacherMonitor":
					// get teachers connected to admin
					var tobeInformedTeachers = {};

					// teachers in admin room
					console.log('adminTeacherMonitor - teachers in admin room');
					console.log(roomsTeacherConnectedToAdmin);
					console.log(data.content);

					for (var i in roomsTeacherConnectedToAdmin) {
						if (roomsTeacherConnectedToAdmin[i].adminId == data.content.adminId) {
							var teacherId = roomsTeacherConnectedToAdmin[i].teacherId;
							tobeInformedTeachers[teacherId] = roomsTeacherConnectedToAdmin[i];

							// join the admin to this teacher to receive broadcast from teacher
							socket.join(teacherId);
						}
					}
					console.log('inform this teachers');
					console.log(tobeInformedTeachers);
					console.log(data.command);

					// broadcast data to self
					// connect.io.in(data.content.adminId).emit('common.generalCommand', {
					// 	command: data.command,
					// 	content: { data : data.content, connectedTeachers : connectedTeachers, roomsTeacherConnectedToAdmin : tobeInformedTeachers }
					// });
					socket.emit('common.generalCommand', {
						command: data.command,
						content: { data : data.content, connectedTeachers : connectedTeachers, roomsTeacherConnectedToAdmin : tobeInformedTeachers }
					});

					return resolve();
					break;
				case "informTeachersToCallAdmin":
					var teacherCallers = data.content.teacherCallers;
					console.log('teacher callers');
					console.log(teacherCallers);
					console.log(data);

					var keyAdminCallQueue = Object.keys(adminCallQueue);
					console.log(adminCallQueue);

					if (typeof keyAdminCallQueue !== undefined && keyAdminCallQueue[0] !== undefined) {
						console.log('key admin call queueu: ' + keyAdminCallQueue);
						data.content.teacherId = adminCallQueue[keyAdminCallQueue[0]].teacherId;
						data.content.adminId = adminCallQueue[keyAdminCallQueue[0]].adminId;
						data.content.adminPeerId = adminCallQueue[keyAdminCallQueue[0]].adminPeerId;
						data.content.adminPeerID = adminCallQueue[keyAdminCallQueue[0]].adminPeerId;

						console.log(data.content);
						connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
							command: "callAdmin",
							content: data.content
						});

						delete adminCallQueue[keyAdminCallQueue[0]];
					}
					resolve();
					break;
				/* force teacher to logout from admin side */
				case "forceTeacherLogout":
				case "forceTerminateLesson":
				default:
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: data.command,
						content: { data : data.content, connectedTeachers : connectedTeachers }
					});
					resolve();
			}

		})
		.then(function(content){
			// set socket information
			socket.userData = data.content;

			var memberType = socket.userData.memberType;

			var command = data.command;

			switch (command) {
				case "registerRoom":
					if (memberType == "student"){
						util.log('STUDENT TO JOIN ON TEACHERS ROOM');
						// if teacher exist in room then teacher is online
						if (typeof roomsTeacher['teacher_' + socket.userData.teacherId] !== 'undefined') {
							util.log('USER JOINED TO TEACHER ROOM INDEX: teacher_' + socket.userData.teacherId + ' ' + JSON.stringify(roomsTeacher['teacher_' + socket.userData.teacherId]));
							util.log('USER HAS JOINED TO TEACHER: '+roomsTeacher['teacher_' + socket.userData.teacherId].teacherId);

							// join the user to this teacher
							socket.join(roomsTeacher['teacher_' + socket.userData.teacherId].teacherId);
							// broadcast the teacher data including the broadcaster
							connect.io.in(socket.userData.teacherId).emit('common.generalCommand',{
								command: "updateTeacherStatus",
								content: roomsTeacher['teacher_' + socket.userData.teacherId]
							});
						} else {
							// teacher is offline
							util.log('TEACHER NOT EXIST, OFFLINE');
						}
					} else if (memberType == "teacher"){
						/* emit to self */
						var callAdminContent = false;
						console.log('teacher trigger');
						console.log(roomsTeacherConnectedToAdmin);
						for (var i in roomsTeacherConnectedToAdmin) {
							if (typeof roomsTeacherConnectedToAdmin[i] !== undefined && roomsTeacherConnectedToAdmin[i].teacherId == data.content.teacherId) {
								callAdminContent = roomsTeacherConnectedToAdmin[i];
								callAdminContent.teacherCallers = [ callAdminContent.teacherId ];
								 // set adminPeerID 
								callAdminContent.adminPeerID = callAdminContent.adminPeerId;
								callAdminContent.teacherTrigger = true;
								callAdminContent.roomsTeacherConnectedToAdmin = roomsTeacherConnectedToAdmin;
								console.log('teacher trigger');
								 // if this teacher is connected to admin, call admin 
								socket.emit('common.generalCommand', {
									command: 'adminTeacherMonitor',
									content: callAdminContent
								});
							} 
						}

						/* broadcast to all students who were connected to this teacher's detail page about the new status of this teacher */
						connect.io.in(socket.userData.teacherId).emit('common.generalCommand', {
							command: "updateTeacherStatus",
							content: data.content
						});
					} else {
						util.log("admin");
					}
					break;
				/* if student triggered the advance to lesson inform the other users who were connected to this teacher's detail page */
				case "lessonStart":
					if (memberType == "student"){
						connect.io.in(socket.userData.teacherId).emit('common.generalCommand',{
							command: "lessonStart",
							content: data.content
						});
					}
					break;
				/* teachers statistics */
				case "teacherStatusState":
					if (memberType == "teacher"){
						socket.join(connectedTeachers.connectedTeachers);
						// broadcast data includding the sender
						/* broadcast the teacher statistics to all connected teachers */
						connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
							command: data.command,
							content: { data : data.content, connectedTeachers : connectedTeachers }
						});
					}
					break;

				/* teachers statistics and users connected to this user */
				case "updateRoomState":
					/* broadcast to teacher statistics to all connected teachers */
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: "updateTeacherRoomState",
						content: { data : data.content, connectedTeachers : connectedTeachers }
					});
					/* broadcast to all users that are connected to this teacher */
					socket.broadcast.to(data.content.teacherId).emit('common.generalCommand', {
						command: "updateTeacherStatus",
						content: data.content
					});

					break;

				default:

			}

		})
		.catch(function(err){
			util.log(JSON.stringify(data));
			util.log(JSON.stringify(err));
			util.logError("[ROOM] "+ err);
			obj.error = true;
			obj.content = err;
		})
		.then(function(){
			return callback(obj);
		})
	});

	/* catch disconnection module */
	socket.on('disconnect', function(action){
		util.log('[DISCONNECTION]');

		var userData = '';

		util.try(function(resolve,reject){
			// get userdata from socket
			if (typeof socket === undefined || typeof socket.userData === undefined) {
				return reject('undefined socket.userData');
			}
			userData = socket.userData;

			// get the member type
			var memberType = (typeof userData.memberType === "undefined") ? 'unknown' : userData.memberType;
			var command = "";

			if (memberType == "student"){
				command = "studentDisconnect";
				userData.command = command;
				handler.student.leaveRoom({
					data: userData,
					rooms: roomsStudent
				}, reject);

			} else if (memberType == "teacher"){
				// command = "updateTeacherStatus";
				command = "updateTeacherRoomState";
				userData.command = command;
				userData.status = 4;

				socket.userData = userData;

				handler.teacher.leaveRoom({
					data: userData,
					roomsTeacher: roomsTeacher,
					roomsAdmin: roomsAdmin,
					connectedTeachers: connectedTeachers
				}, reject);

			} else {
				command = "adminDisconnect";
				socket.userData = userData;

				console.log('admin disconnect');
				if (userData.memberType == 'admin') {
					handler.admin.removeAllTeachersFromAdmin(userData.adminPeerID, roomsTeacherConnectedToAdmin, adminCallQueue);
				}
			}

			// resolve
			resolve();
		})
		.then(function(){
			var userData = socket.userData;

			var command = userData.command;

			switch (command) {
				case "updateTeacherRoomState":
					// broadcast data includding the sender
					connect.io.in(connectedTeachers.connectedTeachers).emit('common.generalCommand', {
						command: "updateTeacherRoomState",
						content: { data : userData, connectedTeachers : connectedTeachers }
					});
					connect.io.in(userData.teacherId).emit('common.generalCommand', {command: "updateTeacherStatus", content:userData});
					break;
				default:
			}


			socket.leave();
		})
		.catch(function(err){
			util.log(JSON.stringify(userData), 'white', 'magenta');
			util.logError("[DISCONNECTION] "+ err);
		})
		.then(function(){
			socket.leave();
		});
	});
});