/* require fs */
var fs = require("fs");

/* declare constants */
module.exports = {
	/* set default port */
	port: 3001,
	
	/* database information */
	dbName: "english",
	dbHost: "localhost",
	dbUser: "devel",
	dbPass: "",
	dbTime: "+09:00", // set to japanese time
	
	/* average lesson time is 26 minutes */
	lesson: {
		lessonTime : 1560
	},
	
	/* lesson states */
	onair: {
		wait : "1",
		reservation : "2",
		chat : "3"
	}
};