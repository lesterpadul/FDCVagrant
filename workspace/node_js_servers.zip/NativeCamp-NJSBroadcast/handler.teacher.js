/* set dependencies */
var util = require('./util.js');
var constant = require('./constant.js');

/* export student functions */
module.exports = {

	// the teacher has logged in, create/update a room for teacher
	registerRoom: function(obj, resolve, reject){
		if (typeof obj.roomsTeacher === undefined || typeof obj.data === undefined) {
			return reject("reason_invalid_teacher_rooms_params");
		}
		// variable for rooms and teacher data
		var roomsTeacher = obj.roomsTeacher;
		var data = obj.data;
		var connTeachers = obj.connectedTeachers;
		var connectedTeachers = connTeachers.connectedTeachersArr;
		var stealthFlag = data.stealthFlag;
		var homeBase = (typeof data.homeBase === 'undefined') ? 0 : data.homeBase;

		// remove teachers from teachers room and connectedRooms
		util.log('[REGISTER TEACHER ROOM FUNCTION] => REMOVING TEACHER FIRST');
		this.deleteTeacherConnectedRoom({
			data: data,
			connectedTeachers: connTeachers
		});

		// log teachers index room
		util.log('[ROOM - TEACHER] CHECKING ROOM TEACHER-> ' +JSON.stringify(data) + ' index-> teacher_' + data.teacherId);

		// insert / update new data of teacher's room
		roomsTeacher['teacher_' + data.teacherId] = {
			teacherId: data.teacherId,
			workstationId: data.workstationId,
			status: data.status,
			created: util.getCurrentTime()
		}
		util.log('[TEACHER ROOM]', 'yellow');

		// check the stealthflag
		if (stealthFlag === 0 || homeBase === 0) {
			// insert / update the data where the teacher is currently connected
			connectedTeachers['teacher_' + data.teacherId] = {
				teacherId: parseInt(data.teacherId),
				statusState: parseInt(data.statusState),
				created: util.getCurrentTime()
			};
			util.log('[CONNECTED TEACHERS ROOM] - TEACHER HAS BEEN ADDED TO CONNECTED TEACHERS', 'green');
			// insert teacher based on his/her statusState
			this.insertStateRooms({
				data: obj.data,
				connectedTeachers: obj.connectedTeachers
			});
		}
		return resolve();
	},

	updateTeacherRoomState: function(obj, resolve, reject){
		util.log('[ROOM TEACHER UPDATE]', 'yellow');

		var data = obj.data;
		var connTeachers = obj.connectedTeachers;
		var connectedTeachers = connTeachers.connectedTeachersArr;
		var roomsTeacher = obj.roomsTeacher;
		// teacher already connected
		if (typeof connectedTeachers['teacher_' + data.teacherId] !== 'undefined') {
			this.deleteTeacherConnectedRoom({
				data: data,
				connectedTeachers: obj.connectedTeachers
			});

			this.insertStateRooms({
				data: obj.data,
				connTeachers: obj.connectedTeachers
			});

			util.log('[UPDATE TEACHER ROOM CONNECTED] TEACHER: '+JSON.stringify(data), 'green', 'white');
		}

		return resolve();
	},

	// teacher leaves room / disconnected
	leaveRoom: function(obj){
		// check if the teachers array or data from teacher exists
		if(typeof obj.roomsTeacher === undefined || typeof obj.data === undefined) {
			return reject("reason_invalid_teacher_params");
		}
		// get data
		var roomsTeacher = obj.roomsTeacher;
		var data = obj.data;
		var connTeachers = obj.connectedTeachers;
		var connectedTeachers = connTeachers.connectedTeachersArr;

		if (typeof roomsTeacher['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[DISCONNECTION - ROOM TEACHER] REMOVING TEACHER: '+JSON.stringify(roomsTeacher['teacher_' + data.teacherId]), 'red');
			delete roomsTeacher['teacher_' + data.teacherId];
		}

		if (typeof connectedTeachers['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[DISCONNECTION - CONNECTED TEACHERS ROOM] - REMOVING TEACHER: '+JSON.stringify(connectedTeachers['teacher_' + data.teacherId]), 'red');
			delete connectedTeachers['teacher_' + data.teacherId];
		}

		/* deleting teacher from its current state */
		this.deleteTeacherConnectedRoom({
			data: obj.data,
			connectedTeachers: obj.connectedTeachers
		});
	},

	deleteTeacherConnectedRoom: function(obj){
		var data = obj.data;
		var connTeachers = obj.connectedTeachers;

		if (typeof connTeachers.standby['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN STANDBY] TEACHER: '+JSON.stringify(connTeachers.standby['teacher_' + data.teacherId]), 'red');
			delete connTeachers.standby['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.notStandby['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN NOT STANDBY] TEACHER: '+JSON.stringify(connTeachers.notStandby['teacher_' + data.teacherId]), 'red');
			delete connTeachers.notStandby['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.break['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN BREAK] TEACHER: '+JSON.stringify(connTeachers.break['teacher_' + data.teacherId]), 'red');
			delete connTeachers.break['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.mealBreak['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN MEAL BREAK] TEACHER: '+JSON.stringify(connTeachers.mealBreak['teacher_' + data.teacherId]), 'red');
			delete connTeachers.mealBreak['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.other['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN OTHER] TEACHER: '+JSON.stringify(connTeachers.other['teacher_' + data.teacherId]), 'red');
			delete connTeachers.other['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.onLesson['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN ON LESSON] TEACHER: '+JSON.stringify(connTeachers.onLesson['teacher_' + data.teacherId]), 'red');
			delete connTeachers.onLesson['teacher_' + data.teacherId];
		}

		if (typeof connTeachers.reservation['teacher_' + data.teacherId] !== 'undefined') {
			util.log('[REMOVING TEACHER IN RESERVATION] TEACHER: '+JSON.stringify(connTeachers.reservation['teacher_' + data.teacherId]), 'red');
			delete connTeachers.reservation['teacher_' + data.teacherId];
		}
	},

	teacherLessonStart: function(obj, resolve, reject){
		util.log('[LESSON START - TEACHER]', 'yellow');

		if (typeof obj === undefined || typeof obj.data === undefined ||
			 typeof obj.connectedTeacher === undefined || typeof obj.roomsTeacher === undefined) {
			return reject('invalid_teacher_lesson_start_variable');
		}

		// delete teacher from connected teachers room
		this.deleteTeacherConnectedRoom({
			data: obj.data,
			connectedTeachers: obj.connectedTeachers
		});
		// inserting teacher to desired state
		this.insertStateRooms({
			data: obj.data,
			connectedTeachers: obj.connectedTeachers
		});

		var roomsTeacher = obj.roomsTeacher;

		// insert / update rooms teacher
		roomsTeacher['teacher_' + data.teacherId] = {
			teacherId: obj.data.teacherId,
			workstationId: obj.data.workstationId,
			status: obj.data.status,
			created: util.getCurrentTime()
		};
		return resolve();
	},

	insertStateRooms: function(obj){
		var data = obj.data;
		var connTeachers =  obj.connectedTeachers;

		var homeBase = data.homeBase;
		var stealthFlag = data.stealthFlag;
		if (stealthFlag == 1 || homeBase == 1) {
			return;
		}

		if (data.statusState == 1) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO NOT STANDBY -> '+JSON.stringify(data), 'green');
			connTeachers.notStandby['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 2) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO STANDBY -> '+JSON.stringify(data), 'green');
			connTeachers.standby['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 3) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO BREAK -> '+JSON.stringify(data), 'green');
			connTeachers.break['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 4) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO MEAL BREAK -> '+JSON.stringify(data), 'green');
			connTeachers.mealBreak['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 5) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO OTHER -> '+JSON.stringify(data), 'green');
			connTeachers.other['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 6) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO ON LESSON -> '+JSON.stringify(data), 'green');
			connTeachers.onLesson['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		} else if (data.statusState == 7) {
			util.log('[CONNECTED TEACHER ROOMS] - INSERTING TEACHER TO ON RESERVATION -> '+JSON.stringify(data), 'green');
			connTeachers.reservation['teacher_' + data.teacherId] = { teacherId : parseInt(data.teacherId), created: util.getCurrentTime() };
		}
	},

	updateRoomState: function (obj, res, rej){
		util.log('[UPDATE ROOM STATE]', 'yellow');

		if (typeof obj === undefined || typeof obj.data === undefined ||
			 typeof obj.connectedTeacher === undefined || typeof obj.roomsTeacher === undefined) {
			return rej('invalid_teacher_update_room_state_variable');
		}

		// delete teacher from connected teachers room
		this.deleteTeacherConnectedRoom({
			data: obj.data,
			connectedTeachers: obj.connectedTeachers
		});
		// inserting teacher to desired state
		this.insertStateRooms({
			data: obj.data,
			connectedTeachers: obj.connectedTeachers
		});

		var roomsTeacher = obj.roomsTeacher;

		// insert / update teachers room with its new information
		roomsTeacher['teacher_' + obj.data.teacherId] = {
			teacherId: obj.data.teacherId,
			workstationId: obj.data.workstationId,
			status: obj.data.status,
			created: util.getCurrentTime()
		};

		/* return resolve */
		return res();
	}
};

